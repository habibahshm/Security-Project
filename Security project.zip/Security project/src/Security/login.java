package Security;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class login extends JFrame {
	private JButton login;
	private JTextField userfield;
	private JPasswordField passfield;

	private JLabel username;
	private JLabel password;
	
	Client client;

	public JButton getLogin() {
		return login;
	}

	public void setLogin(JButton login) {
		this.login = login;
	}

	public JLabel getUsername() {
		return username;
	}

	public void setUsername(JLabel username) {
		this.username = username;
	}

	public JLabel getPassword() {
		return password;
	}

	public void setPassword(JLabel password) {
		this.password = password;
	}

	public login() {
		super("LOGIN");
		JLabel back = new JLabel();
		username = new JLabel("Username");
		username.setHorizontalTextPosition(JLabel.CENTER);
		username.setVerticalTextPosition(JLabel.CENTER);
		username.setBounds(30, 0, 300, 50);
		back.add(username);

		userfield = new JTextField(20);
		userfield.setBounds(30, 40, 300, 50);
		back.add(userfield);

		password = new JLabel("Password");
		password.setHorizontalTextPosition(JLabel.CENTER);
		password.setVerticalTextPosition(JLabel.CENTER);
		password.setBounds(30, 80, 300, 50);
		back.add(password);

		passfield = new JPasswordField(20);
		passfield.setBounds(30, 120, 300, 50);
		back.add(passfield);

		login = new JButton("Login");
		login.setBounds(30, 200, 300, 50);
		login.setHorizontalTextPosition(JButton.CENTER);
		login.setVerticalTextPosition(JButton.CENTER);
		login.setActionCommand("login");
		back.add(login);
		add(back);

//		this.login.setActionCommand("LOGIN");
		// this.field.setActionCommand("field");

		JLabel note = new JLabel("If you are not registered?!");
		note.setForeground(Color.RED);
		note.setHorizontalTextPosition(JLabel.CENTER);
		note.setVerticalTextPosition(JLabel.CENTER);
		note.setBounds(30, 260, 300, 15);
		back.add(note);

		note = new JLabel("We will register you using these credentials");
		note.setForeground(Color.RED);
		note.setHorizontalTextPosition(JLabel.CENTER);
		note.setVerticalTextPosition(JLabel.CENTER);
		note.setBounds(30, 275, 320, 30);
		note.setForeground(Color.RED);
		back.add(note);

		this.setSize(380, 320);
		this.setLocationRelativeTo(null);
		setFocusable(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setFocusable(true);
		requestFocus();
		this.setVisible(true);
	}

	void addListener(SuperClient c) {
		client = (Client)c;
		login.addActionListener(c);
		
		addWindowListener(new java.awt.event.WindowAdapter() {
		    @Override
		    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
		    	client.quit_signup_login();
		    }
		});
	}

	public JButton getEnter() {
		return login;
	}

	public void setEnter(JButton enter) {
		this.login = enter;
	}

	public JTextField getuserField() {
		return userfield;
	}

	public JPasswordField getpassField() {
		return passfield;
	}

	// public void setField(JTextField field) {
	// this.field = field;
	// }
//	public void windowClosing(WindowEvent e) {
//		client.quit_signup_login();;
//		 System.exit(0);
//		
//	}


//	public static void main(String[] args) {
//		new login();
//	}

}
