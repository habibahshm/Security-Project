package Security;

import java.awt.FlowLayout;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.awt.image.WritableRaster;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Chat {
	static String delimter = "$%^&*()";

	public static String recieve(Socket sock, String pu) throws IOException {
		try {
			BufferedImage image = ImageIO.read(sock.getInputStream());
			if (image != null) {

				// JFrame original_image_frame = new JFrame();
				// original_image_frame.getContentPane().setLayout(new
				// FlowLayout());
				// original_image_frame.getContentPane().add(new JLabel(new
				// ImageIcon(image)));
				// original_image_frame.pack();
				// original_image_frame.setTitle("recieved_image");
				// original_image_frame.setVisible(true);

				String recieved_message = Steganography.decode(image);
				System.out.println("stygnapgry: " + recieved_message);
				System.out.println("before decryption: " + recieved_message);
				Pattern pattern = Pattern.compile(Pattern.quote(delimter));
				String[] data = pattern.split(recieved_message);
				// StringTokenizer st = new StringTokenizer(recieved_message, "$");
				recieved_message = data[0];
				String hashed = data[1];
				hashed = decrypt(hashed, pu);

				if (hashed.equals(hash(recieved_message)))
					return recieved_message;
				else
					return "Message Corrupted";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

	public static void send(String message, String pr, OutputStream ostream) throws Exception {
		String messageHash = hash(message);
		String encryptedHash = encrypt(messageHash, pr);
		message = message + delimter + encryptedHash;
		System.out.println("Sending: " + message);

		BufferedImage encoded = Steganography.encode(message);
		File encoded_file = new File("encoded.png");
		ImageIO.write(encoded, "png", encoded_file);

		BufferedInputStream in = new BufferedInputStream(new FileInputStream(encoded_file));
		WritableRaster raster = encoded.getRaster();
		int size = ((DataBufferByte) raster.getDataBuffer()).getData().length;
		byte[] buffer = new byte[size];
		int bytesRead;
		while ((bytesRead = in.read(buffer, 0, buffer.length)) != -1) {
			ostream.write(buffer, 0, bytesRead);

		}

		System.out.println("Done.");

	}

	public static String recievePublic(Socket sock) throws IOException {
		try {
			BufferedImage image = ImageIO.read(sock.getInputStream());
			if (image != null) {
				String recieved_message = Steganography.decode(image);

				//StringTokenizer st = new StringTokenizer(recieved_message, "$");
				Pattern pattern = Pattern.compile(Pattern.quote(delimter));
				String[] data = pattern.split(recieved_message);
				recieved_message = data[0];
				String hashed = data[1];

				if (hashed.equals(hash(recieved_message)))
					return recieved_message;
				else
					return "Message Corrupted";
			}
		} catch (Exception e) {
			return e.getMessage();
		}
		return null;

	}

	public static void sendPublic(String message, OutputStream ostream) throws Exception {
		String messageHash = hash(message);
		message = message + delimter + messageHash;

		File imageFile = new File("mario.jpeg");

		BufferedImage encoded = Steganography.encode(message);
		File encoded_file = new File("encoded.png");
		ImageIO.write(encoded, "png", encoded_file);

		BufferedInputStream in = new BufferedInputStream(new FileInputStream(encoded_file));
		WritableRaster raster = encoded.getRaster();
		int size = ((DataBufferByte) raster.getDataBuffer()).getData().length;
		byte[] buffer = new byte[size];
		int bytesRead;
		while ((bytesRead = in.read(buffer, 0, buffer.length)) != -1) {
			ostream.write(buffer, 0, bytesRead);

		}

		System.out.println("Done.");

	}

	public static String hash(String s) {
		String generatedMessage = null;
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] bytes = md.digest(s.getBytes());
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < bytes.length; i++) {
				sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
			}
			generatedMessage = sb.toString();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return generatedMessage;
	}

	public static PublicKey getPublicKey(String base64PublicKey) {
		PublicKey publicKey = null;
		try {
			X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(base64PublicKey.getBytes()));
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			publicKey = keyFactory.generatePublic(keySpec);
			return publicKey;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (InvalidKeySpecException e) {
			e.printStackTrace();
		}
		return publicKey;
	}

	public static PrivateKey getPrivateKey(String base64PrivateKey) {
		PrivateKey privateKey = null;
		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(base64PrivateKey.getBytes()));
		KeyFactory keyFactory = null;
		try {
			keyFactory = KeyFactory.getInstance("RSA");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		try {
			privateKey = keyFactory.generatePrivate(keySpec);
		} catch (InvalidKeySpecException e) {
			e.printStackTrace();
		}
		return privateKey;
	}

	public static String encrypt(String plainText, String privateKey) throws Exception {
		Cipher encryptCipher = Cipher.getInstance("RSA");
		encryptCipher.init(Cipher.ENCRYPT_MODE, getPrivateKey(privateKey));

		byte[] cipherText = encryptCipher.doFinal(plainText.getBytes());

		return Base64.getEncoder().encodeToString(cipherText);
	}

	public static String decrypt(String cipherText, String publicKey) throws Exception {
		byte[] bytes = Base64.getDecoder().decode(cipherText);

		Cipher decriptCipher = Cipher.getInstance("RSA");
		decriptCipher.init(Cipher.DECRYPT_MODE, getPublicKey(publicKey));

		return new String(decriptCipher.doFinal(bytes));
	}

//	public static void main(String[] args) throws Exception {
//		// First generate a public/private key pair
//		KeyGenerator pair = new KeyGenerator();
//
//		// Our secret message
//		String message = "the answer to life the universe and everything";
//
//		// Encrypt the message
//		String cipherText = encrypt(message, pair.getPrivateKey());
//
//		// Now decrypt it
//		String decipheredMessage = decrypt(cipherText, pair.getPublicKey());
//
//		System.out.println(decipheredMessage);
//
//		Pattern pattern = Pattern.compile(Pattern.quote(delimter));
//		String[] data = pattern.split("hi" + delimter + "hiiiiii");
//		System.out.println(Arrays.toString(data));
//
//	}

}
