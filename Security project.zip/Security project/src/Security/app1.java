package Security;

import java.awt.Font;
import java.awt.event.WindowEvent;
import java.util.TreeMap;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JViewport;

public class app1 extends JFrame {

	JTextField inputText;
	JTextField username;
	JTextField password;

	JComboBox onlineUsers;
	JTextArea area = new JTextArea();
	JTabbedPane tabs = new JTabbedPane();

	JButton sendToAll;
	JButton getOnlineUsers;
	JButton send;
	static Client client;

	TreeMap<String, Integer> tabs_idx = new TreeMap<String, Integer>();
	TreeMap<Integer, String> tabs_name = new TreeMap<Integer, String>();
	TreeMap<String, JTextArea> areas = new TreeMap<String, JTextArea>();
	static int count = 0;

	public app1() {
		super();

		// area.setEditable(false);
		// area.setLineWrap(true);
		// JScrollPane pane = new JScrollPane(area,
		// JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
		// JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		setLayout(null);
		// pane.setBounds(20, 20, 645, 400);
		// add(pane);

		// JTextArea area2 = new JTextArea();
		// area2.append("area2");
		// JScrollPane pane2 = new JScrollPane(area2,
		// JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
		// JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		tabs.setBounds(20, 20, 645, 400);
		// tabs.add("bito", pane);
		// tabs.add("bito2", pane2);

		add(tabs);

		send = new JButton("Send");
		send.setBounds(515, 430, 150, 30);
		add(send);

		getOnlineUsers = new JButton("Get Online Users");
		getOnlineUsers.setBounds(515, 470, 150, 30);
		add(getOnlineUsers);

		sendToAll = new JButton("Send To All");
		sendToAll.setBounds(515, 500, 150, 30);
		add(sendToAll);

		inputText = new JTextField(30);
		inputText.setBounds(20, 430, 460, 30);
		add(inputText);

		String[] temp = { "PICK A USER" };
		onlineUsers = new JComboBox(temp);
		onlineUsers.setBounds(20, 470, 460, 30);
		onlineUsers.setEnabled(false);
		add(onlineUsers);

		this.send.setActionCommand("SEND");
		this.sendToAll.setActionCommand("SENDTOALL");
		getOnlineUsers.setActionCommand("ONLINEUSERS");

		this.setSize(700, 560);
		this.setLocationRelativeTo(null);
		setFocusable(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setFocusable(true);
		requestFocus();
		this.setVisible(false);

	}

	void addListener(Client c) {
		client = c;
		send.addActionListener(c);
		sendToAll.addActionListener(c);
		getOnlineUsers.addActionListener(c);
		addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosing(java.awt.event.WindowEvent windowEvent) {
				client.quit_app();
			}
		});
	}

	public JTextArea getCurrentTextArea(String name) {
		return areas.get(name);
	}

	public JTextArea selectbyname(String name) {
		tabs.setSelectedIndex(tabs_idx.get(name));
		return getCurrentTextArea(name);
	}

	public String getCurrentActive() {
		int idx = tabs.getSelectedIndex();
		return tabs_name.get(idx);
	}

	public void add_tab(String name) {
		JTextArea area = new JTextArea();
		area.setEditable(false);
		area.setLineWrap(true);
		JScrollPane pane = new JScrollPane(area, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		areas.put(name, area);
		pane.setBounds(20, 20, 645, 400);
		tabs.add(name, pane);
		tabs.setSelectedIndex(count);
		tabs_idx.put(name, count);
		tabs_name.put(count, name);
		count++;
	}

	// public static void main(String args[]) {
	// new app1();
	// }
}
