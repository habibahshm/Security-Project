package Security;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;

public class KeyGenerator {
	private PrivateKey privateKey;
	private PublicKey publicKey;

	public KeyGenerator() throws NoSuchAlgorithmException {
		SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
		KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
		keyGen.initialize(2048, random);
		KeyPair pair = keyGen.generateKeyPair();
		this.privateKey = pair.getPrivate();
		this.publicKey = pair.getPublic();

	}

	public String getPrivateKey() {
		return Base64.getEncoder().encodeToString(privateKey.getEncoded());
	}

	public String getPublicKey() {
		return Base64.getEncoder().encodeToString(publicKey.getEncoded());
	}

	public void generatekeys() throws NoSuchAlgorithmException, IOException, InvalidKeySpecException {

		KeyGenerator keyPairGenerator = new KeyGenerator();

	}

}
