package Security;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.Collection;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.regex.Pattern;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Server {
	static TreeMap<String, Socket> online = new TreeMap<>();
	static TreeMap<String, String> ports = new TreeMap<>();
	static TreeMap<String, String> publicKeys = new TreeMap<>();

	// static FileWriter fileWriter;
	static String privateKey = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCdlPAFaZdaWvqRfLyDsjPWKDbdoc3WmR3Y0oE10CrsxvoajqS6h1e2w2tTGSStMn7+M3oKgeyio/LthxWSJ1wC+xJuAPiu+HBhkxZMt8NAmQjVcllmh6Y7VA/xBiJQV8lpEh1D3sOsDh0AxOryulHxGxxyRgIAs3GWy3TL1DGfVNfJ4en1RoqiJ6hbXcIrKBRL417/Ba4qUA4LmGMogCiCwQaXU9CXk9Iolw8jNZYgkGt8CG0rgrB+zb0+L9CUZZ3TZT9yUoNr7CuC9c2msKndky1Ia6pLpnbS2E62xxkUJrz/OY+6ZHZK6hSQSjc4bCAXVoPhXJQolWq8i29fcqtJAgMBAAECggEAF9havabtxTlxIyTJ7e/AUk7BhqYeXLPMxWuNK9R1OmEdpXkiSiuCxWAq1GdAmojCmLq3Y/GnGjFO6EyBoh0cmkLd1hGFkAx+DPXR8Qf5nsPJh2sHRjGOoPmmc+Vmudue2axpC0UhPN7h2qTxnIs/LQnaMxyO3wZIUPY2lUVlwOM75Vj/S0N8ZPvcmn6Ebv16CxLINmftXmbXoeB8ap2T3cm/vW1sXPE2l5pPECHbDdmDJZ3LLOkwnYxdOAwIfaiS1i4gwOgTf9TEbw0/tyX53YfTjFwzJdIUTBNDB7PdbCQ4Z3vvNEy+YdajOY48WBeZUHsde4TqE45wHGWsgwopgQKBgQDUrhunKWrcNd4NunhE3JLmIqWPo3mi62eeG/3KL4R6eBEfl9rpc3WGhDYrgeMAE9gANNncv5jh7qiCRrs24rJGzR2ZyJ2YzvjjsJ9UCV4CYMyN4jSRKBTcoFskFxdNiI+CCVK20D0kE7hXTk2WX+W3h+BkyfHJ7gy/yqNLWgpfkQKBgQC9rc74NlJiVhSk0OHMxqWsvXITlHAk//ekFodbvRGBmyC5C0PixN/qGELgNhefHjvQT84t2DHXROxXexNr7vTELG8ro1XBLwAhFD/x+eaYbLOYc08/Srke9LoPQvbvm42dAr+eISpFrj/H1iyycVIzlmT0tsIhSbmlX5JCTwMkOQKBgEb3QarpmwqXvtx92BvCLhI0hWIEflXqjsynMmwApwfmgHA2T4mOSSz1eM3TrVcdR/npqLiMBgt9gyTVTSrnQe12C+aAlnWiulHfYYq9BW1tt1OwozG8Whm0ODU2r0PjyV7ulXcCzSP4oI4hRqpinVg8Mpfu+osSr5Zfm1VNWiDBAoGBAIlvbK3QvnTeJmsdpt53eQfm5MdnILLOfSL55+4C2rJsMpOho/il6hB2r85Bo2/5uiFAEgaJxeNS32SrmvDz3YpfH9YgrTwi0Bcn0wWDqx/6c08dDeiwPd4+OKpiPQZ0UXHY0frD0RtYHIKxnwVUstkKOfBOk+8GumsnCpTdJ0uRAoGBALpxKeLHjHUH5kgdWzi+itn2HdpLyIeGvJXmkl6vqiAjIJ5pKyG9b1FQ391IjQU8c5e9dCnTqortgaLJsKNH8ZKsZkIViKnMAecVH2hnN2oHhRw0rujvqos/i9AGk5W6frH8AtDQSvdY0sXtBcZ1h2K2yrF76Fge4hcNIX0iW3zk";
	static String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnZTwBWmXWlr6kXy8g7Iz1ig23aHN1pkd2NKBNdAq7Mb6Go6kuodXtsNrUxkkrTJ+/jN6CoHsoqPy7YcVkidcAvsSbgD4rvhwYZMWTLfDQJkI1XJZZoemO1QP8QYiUFfJaRIdQ97DrA4dAMTq8rpR8RscckYCALNxlst0y9Qxn1TXyeHp9UaKoieoW13CKygUS+Ne/wWuKlAOC5hjKIAogsEGl1PQl5PSKJcPIzWWIJBrfAhtK4Kwfs29Pi/QlGWd02U/clKDa+wrgvXNprCp3ZMtSGuqS6Z20thOtscZFCa8/zmPumR2SuoUkEo3OGwgF1aD4VyUKJVqvItvX3KrSQIDAQAB";

	static String delimter = "h3m1!@#";

	public static class Pair {
		String salt, hashed_password;

		public Pair(String hashed_password, String salt) {
			this.salt = salt;
			this.hashed_password = hashed_password;
		}
	}

	public static void writeToFile(String username, String password)
			throws IOException, NoSuchAlgorithmException, NoSuchProviderException {
		FileWriter fileWriter = new FileWriter("password.csv", true);
		PrintWriter writer = new PrintWriter(fileWriter);

		// hashing password and saving salt
		byte[] salt = PasswordHash.getSalt();
		String hashed_password = PasswordHash.getSecurePassword(password, salt);

		StringBuilder sb = new StringBuilder();
		sb.append(username);
		sb.append(',');
		sb.append(hashed_password);
		sb.append(',');
		sb.append(java.util.Base64.getEncoder().encodeToString(salt));
		System.out.println("writing " + username);
		writer.println(sb.toString());
		writer.flush();
		writer.close();
		fileWriter.close();

	}

	public static Pair readFromFile(String username) throws IOException {
		try {
			FileReader fileReader = new FileReader("password.csv");
			BufferedReader bf = new BufferedReader(fileReader);
			String row = bf.readLine();
			while (row != null && row.length() > 0) {
				System.out.println("row: " + row);
				StringTokenizer st = new StringTokenizer(row, ",");
				String fileusername = st.nextToken();
				String password = st.nextToken();
				String salt = st.nextToken();
				System.out.println("compare " + fileusername + "  " + username);
				if (fileusername.equals(username)) {
					System.out.println("found");
					return new Pair(password, salt);
				}
				row = bf.readLine();
			}
			bf.close();
			fileReader.close();

		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
			File file = new File("password.csv");
			file.createNewFile();
		}

		return null;
	}

	public static boolean signup_login(String InputUsername, String InputPassword) throws Exception {
		Pair outputFromRead = readFromFile(InputUsername);
		System.out.println("out: " + outputFromRead);
		if (outputFromRead == null) {
			writeToFile(InputUsername, InputPassword);
			return true;
		} else {
			String stored_password = outputFromRead.hashed_password;
			byte[] salt = java.util.Base64.getDecoder().decode(outputFromRead.salt);
			String user_hashed_password = PasswordHash.getSecurePassword(InputPassword, salt);
			System.out.println("stored: " + stored_password);
			System.out.println("userPass: " + user_hashed_password);
			if (user_hashed_password.equals(stored_password)) {
				return true;
			} else {
				return false;
			}
		}

	}

	public static void main(String[] args) throws Exception {
		Socket clientSocket = null;
		try {
			ServerSocket serverSocket = new ServerSocket(6000);
			int id = 1;
			while (!serverSocket.isClosed()) {
				clientSocket = serverSocket.accept();
				MultiThread th = new MultiThread(clientSocket, id++);
				th.start();

			}

		} catch (IOException e) {
			System.out.println(e.getMessage());

		}

	}

	static class MultiThread extends Thread {
		Socket cs;
		int cID;
		String username;
		boolean flag = true;
		boolean publicRecived = false;

		MultiThread(Socket s, int i) {
			cs = s;
			cID = i;
		}

		public static String joinResponse(String name, Socket s, String port_num) {
			if (online.containsKey(name)) {
				return "reject";
			} else {
				online.put(name, s);
				ports.put(name, port_num);
				return "joined";
			}
		}

		public static String memberListResponse() {
			Collection<String> c = online.keySet();
			Iterator<String> i = c.iterator();
			String s = "List" + delimter;
			while (i.hasNext()) {
				s += (i.next() + delimter);
			}
			return s;
		}

		public static String portAllResponse() {
			Collection<String> u = online.keySet();
//			Collection<String> p = ports.values();
//			Collection<String> pu = publicKeys.values();
			Iterator<String> i_u = u.iterator();
			// Iterator<String> i_p = p.iterator();
			// Iterator<String> i_pu = pu.iterator();
			String s = "";
			while (i_u.hasNext()) {
				String user = i_u.next();
				s += (user + delimter + ports.get(user) + delimter + publicKeys.get(user) + delimter);
			}
			return s;
		}

		public void run() {
			System.out.println("connected to client " + cID + " Address : " + cs.getInetAddress().getHostName());
			System.out.println(online.toString());
			try {
				DataInputStream in = new DataInputStream(cs.getInputStream());
				DataOutputStream out = new DataOutputStream(cs.getOutputStream());
				try {
					System.out.println("waiting for public");
					while (!publicRecived) {
						System.out.println("public recived");
						String s = Chat.recievePublic(cs);
						if(!s.equals("Message Corrupted")){
							System.out.println(s);
							// StringTokenizer st = new StringTokenizer(s, dilemter);
							Pattern pattern = Pattern.compile(Pattern.quote(delimter));
							String[] data = pattern.split(s);
							if (data[0].equals("publicKey")) {
								username = data[1];
								publicKeys.put(username, data[2]);
								publicRecived = true;
							}
						}else{
							JOptionPane.showMessageDialog(new JFrame(), "Corrupt message", "ERROR",
									JOptionPane.ERROR_MESSAGE);
						}

					}
					while (flag && publicRecived) {
						String s = "";
						try {
							s = Chat.recieve(cs, publicKeys.get(username));
						} catch (Exception e) {
							flag = false;
						}
						System.out.println("Client " + username + " Says :" + s);



						if (s != null) {
							if (!s.equals("Message Corrupted")) {
									// StringTokenizer st = new StringTokenizer(s, dilemter);
								Pattern pattern = Pattern.compile(Pattern.quote(delimter));
								String[] data = pattern.split(s);

								String a = "";
								String b = "";
								String c = "";

								a = data[0];

								if (a.equalsIgnoreCase("getlist")) {
									Chat.send(memberListResponse(), privateKey, cs.getOutputStream());
								} else if (a.equalsIgnoreCase("bye") || a.equalsIgnoreCase("quit")) {
									flag = false;
									for (int i = 1; i < data.length; i++) {
										b = data[i];
										online.remove(b);
										ports.remove(b);
									}
								} else if (a.equals("port")) {
									String requested_name = data[1];
									Chat.send("port" + delimter + ports.get(requested_name) + delimter
											+ publicKeys.get(requested_name), privateKey, cs.getOutputStream());
								} else if (a.equals("portall")) {
									Chat.send("portall" + delimter + portAllResponse(), privateKey, cs.getOutputStream());
								} else if (a.equals("isOnline")) {
									Chat.send("isOnline" + delimter + online.containsKey(data[1]), privateKey,
											cs.getOutputStream());

								} else {
									b = data[1];
									c = data[2];

									boolean signedIn = signup_login(b, c);
									System.out.println("STATUS: " + signedIn);
									if (signedIn) {
										String status = joinResponse(b, cs, data[3]);
										if (status.equals("joined")) {
											Chat.send("JOINED", privateKey, cs.getOutputStream());
										} else
											Chat.send("ERROR", privateKey, cs.getOutputStream());

									} else {
										Chat.send("ERROR", privateKey, cs.getOutputStream());
									}
								}
							}else{
							JOptionPane.showMessageDialog(new JFrame(), "Corrupt message", "ERROR",
									JOptionPane.ERROR_MESSAGE);
						}

							
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println("Client" + cID + "closed");
				}

				in.close();
				out.close();
				cs.close();
			} catch (Exception e) {
				e.printStackTrace();
				flag = false;
			}
		}
	}
}
