package Security;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.awt.image.DataBufferByte;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Steganography {
	static String images[] = { "bw.jpeg", "ca.jpeg", "h.jpeg", "im.jpeg", "mario.jpeg", "thor.jpeg" };

	public static BufferedImage encode(String message) {
		Random r = new Random();
		int randomNumber = r.nextInt(images.length);
		System.out.println(images[randomNumber]);
		// read the original image
		BufferedImage original_image = null;
		try {
			original_image = ImageIO.read(new File(images[randomNumber]));
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}

		int message_length = message.length();

		int new_dim = Math.max(100, (int) Math.ceil(Math.sqrt(message_length) * 8) + 10);

		// make a copy of the original image
		BufferedImage new_image = new BufferedImage(new_dim, new_dim, BufferedImage.TYPE_3BYTE_BGR);
		Graphics2D graphics = new_image.createGraphics();
		graphics.drawImage(original_image, 0, 0, null);
		graphics.setBackground(Color.WHITE);
		graphics.setPaint(Color.WHITE);
		graphics.fillRect(0, 0, new_dim, new_dim);
		graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		graphics.drawImage(original_image, 0, 0, new_dim, new_dim, null); // draw the image scaled
		graphics.dispose();

		// format the data into bytes
		// get the original image's byte array
		WritableRaster raster = new_image.getRaster();
		byte new_image_bytes[] = ((DataBufferByte) raster.getDataBuffer()).getData();
		// get the message bytes
		byte message_bytes[] = message.getBytes();
		// get the message's length bytes
		byte message_length_byte0 = (byte) (message_length & 0x000000FF);
		byte message_length_byte1 = (byte) ((message_length & 0x0000FF00) >>> 8);
		byte message_length_byte2 = (byte) ((message_length & 0x00FF0000) >>> 16);
		byte message_length_byte3 = (byte) ((message_length & 0xFF000000) >>> 24);
		byte messag_length_bytes[] = new byte[] { message_length_byte3, message_length_byte2, message_length_byte1,
				message_length_byte0 };

		// offset used to determine the starting position of the changed bytes
		// in the
		// original image
		int offset = 0;
		try {
			// encode message's length
			if (messag_length_bytes.length + offset > new_image_bytes.length) {
				System.out.println("image cannot encompasses the message");
				throw new IllegalArgumentException("image cannot encompasses the message");
			}
			for (int i = 0; i < messag_length_bytes.length; i++) {
				int byte_toAdd = messag_length_bytes[i];
				for (int j = 7; j >= 0; j--) {
					int bit_toAdd = (byte_toAdd >>> j) & 1;
					new_image_bytes[offset] = (byte) (new_image_bytes[offset++] & 0xFE | bit_toAdd);
				}
			}

			// encode message
			if (message_bytes.length + offset > new_image_bytes.length) {
				System.out.println("image cannot encompasses the message");
				throw new IllegalArgumentException("image cannot encompasses the message");
			}
			for (int i = 0; i < message_bytes.length; i++) {
				int byte_toAdd = message_bytes[i];
				for (int j = 7; j >= 0; j--) {
					int bit_toAdd = (byte_toAdd >>> j) & 1;
					new_image_bytes[offset] = (byte) (new_image_bytes[offset++] & 0xFE | bit_toAdd);
				}
			}

		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return new_image;
	}

	public static String decode(BufferedImage image) {
		byte decoded[] = null;
		try {
			// format the data into bytes
			// get the image's byte array
			WritableRaster raster = image.getRaster();
			byte image_bytes[] = ((DataBufferByte) raster.getDataBuffer()).getData();

			// decode text
			int message_length = 0;
			int offset = 32;
			// extract the message's length
			for (int i = 0; i < 32; i++) {
				message_length = (message_length << 1) | (image_bytes[i] & 1);
			}

			decoded = new byte[message_length];
			// extract the message
			for (int byte_toExtract = 0; byte_toExtract < message_length; byte_toExtract++) {
				for (int bit_toExtract = 0; bit_toExtract < 8; bit_toExtract++) {
					decoded[byte_toExtract] = (byte) ((decoded[byte_toExtract] << 1) | (image_bytes[offset++] & 1));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return (new String(decoded));
	}

	static BufferedImage resize(BufferedImage img, int height, int width) {
		Image tmp = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
		BufferedImage resized = new BufferedImage(width, height, BufferedImage.TYPE_3BYTE_BGR);
		Graphics2D g2d = resized.createGraphics();
		g2d.drawImage(tmp, 0, 0, null);
		g2d.dispose();
		return resized;
	}


}