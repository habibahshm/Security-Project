package Security;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import Security.Server.MultiThread;

public class Client extends SuperClient implements ActionListener {
	static TreeMap<String, Socket> connected_peers = new TreeMap<>();
	static TreeMap<String, String> connected_public = new TreeMap<>();
	static Socket outSock;
	static Socket inSocket;
	static OutputStream ostream;
	static InputStream istream;
	static app1 app;
	static int inport;
	static int outport;
	static login login;
	static boolean loginAccepted;
	static Socket serverSocket;
	static Client c;
	static String username;
	static Server_Chat serverChat;
	static int port = 6002;// change this port before running, don't use 6000
	static String peer;
	static String message;
	static boolean sendToAll;
	static KeyGenerator keyGen;
	static boolean publicRecived;
	static String serverPublicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnZTwBWmXWlr6kXy8g7Iz1ig23aHN1pkd2NKBNdAq7Mb6Go6kuodXtsNrUxkkrTJ+/jN6CoHsoqPy7YcVkidcAvsSbgD4rvhwYZMWTLfDQJkI1XJZZoemO1QP8QYiUFfJaRIdQ97DrA4dAMTq8rpR8RscckYCALNxlst0y9Qxn1TXyeHp9UaKoieoW13CKygUS+Ne/wWuKlAOC5hjKIAogsEGl1PQl5PSKJcPIzWWIJBrfAhtK4Kwfs29Pi/QlGWd02U/clKDa+wrgvXNprCp3ZMtSGuqS6Z20thOtscZFCa8/zmPumR2SuoUkEo3OGwgF1aD4VyUKJVqvItvX3KrSQIDAQAB";
	static String delimter = "h3m1!@#";

	public Client() {
		try {
			keyGen = new KeyGenerator();
			serverSocket = new Socket("127.0.0.1", 6000);
			serverChat = new Server_Chat();
			serverChat.start();
			app = new app1();
			app.addListener(this);
			app.setVisible(false);
			login = new login();
			login.addListener(this);

			// app.setVisible(false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static class Server_Chat extends Thread {
		public void run() {
			try {
				while (true) {
					String s = Chat.recieve(serverSocket, serverPublicKey);
					if (s != null) {
						System.out.println("Recieved from server: " + s);
						if (!s.equals("Message Corrupted")) {
							// StringTokenizer st = new StringTokenizer(s);
							Pattern pattern = Pattern.compile(Pattern.quote(delimter));
							String[] data = pattern.split(s);

							String operation = data[0];
							if (operation.equals("JOINED")) {
								System.out.println(username);
								app.setTitle(username);
								app.setVisible(true);
								login.setVisible(false);
								keyGen.generatekeys();
							} else if (operation.equals("ERROR")) {
								JOptionPane.showMessageDialog(new JFrame(), "Wrong Credentials! or If you are a new user, use a different username", "ERROR",
										JOptionPane.ERROR_MESSAGE);

							} else if (operation.equals("List")) {
								// System.out.println(s);
								// System.out.println(username);
								app.onlineUsers.removeAllItems();
								app.onlineUsers.addItem("PICK A USER");
								for (int i = 1; i < data.length; i++) {
									String user = data[i];
									if (!user.equals(username)) {
										app.onlineUsers.addItem(user);
									}
								}
								app.onlineUsers.setEnabled(true);
							} else if (operation.equals("port")) {
								int port = Integer.parseInt(data[1]);
								Socket peerSocket = new Socket("127.0.0.1", port);
								app.add_tab(peer);
								app.getCurrentTextArea(peer).append("you: " + message + "\n");
								connected_public.put(peer, data[2]);
								Peer_Chat chat = new Peer_Chat(peerSocket, peer, true);
								chat.start();
							} else if (operation.equals("portall")) {
								for (int i = 1; i < data.length; i++) {
									String peer = data[i++];
									int port = Integer.parseInt(data[i++]);
									String pub = data[i];
									if (!peer.equals(username)) {
										if (!connected_peers.containsKey(peer)) {
											connected_public.put(peer, pub);
											Socket peerSocket = new Socket("127.0.0.1", port);
											Peer_Chat chat = new Peer_Chat(peerSocket, peer, true);
											app.add_tab(peer);
											app.getCurrentTextArea(peer).append("you: " + message + "\n");
											chat.start();
										} else {
											Chat.send(message, keyGen.getPrivateKey(),
													connected_peers.get(peer).getOutputStream());
											app.selectbyname(peer);
											app.getCurrentTextArea(peer).append("you: " + message + "\n");
										}
									}
								}
							} else if (operation.equals("isOnline")) {
								String isonline = data[1];
								if (isonline.equals("true")) {
									Chat.send(message, keyGen.getPrivateKey(),
											connected_peers.get(peer).getOutputStream());
									app.selectbyname(peer);
									app.getCurrentTextArea(peer).append("you: " + message + "\n");

								} else {
									JOptionPane.showMessageDialog(new JFrame(), peer + " has closed", "ERROR",
											JOptionPane.ERROR_MESSAGE);
								}
							}
						} else {
							JOptionPane.showMessageDialog(new JFrame(), "Corrupt response from server", "ERROR",
									JOptionPane.ERROR_MESSAGE);
						}
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public static class Peer_Chat extends Thread {
		Socket cs;
		String peer;
		boolean flag = true;
		boolean sender;
		boolean intiated;

		Peer_Chat(Socket s, String peer, boolean sender) {
			cs = s;
			this.peer = peer;
			this.sender = sender;
			intiated = sender;
		}

		public void run() {
			try {
				if (sender) {
					connected_peers.put(peer, cs);

					try {
						Chat.sendPublic("initiate" + delimter + username + delimter + keyGen.getPublicKey(),
								cs.getOutputStream());
						Chat.send(message, keyGen.getPrivateKey(), cs.getOutputStream());
					} catch (Exception e) {
						e.printStackTrace();
					}

					sender = false;
				}
				while (flag) {
					String s;
					if (intiated)
						s = Chat.recieve(cs, connected_public.get(peer));
					else
						s = Chat.recievePublic(cs);

					if (s != null) {
						if (!s.equals("Message Corrupted")) {
							System.out.println("message: " + s);
							//StringTokenizer st = new StringTokenizer(s, delimter);
							Pattern pattern = Pattern.compile(Pattern.quote(delimter));
							String[] data = pattern.split(s);
							
							
							String operation = data[0];
							if (operation.equals("initiate")) {
								peer = data[1];
								String peer_puk = data[2];
								connected_peers.put(peer, cs);
								connected_public.put(peer, peer_puk);
								intiated = true;
								app.add_tab(peer);
								System.out.println("awel mara");
							} else {
								System.out.println("3ady");
								app.selectbyname(peer);
								app.getCurrentTextArea(peer).append(peer + ": " + operation + "\n");
							}
						} else {
							JOptionPane.showMessageDialog(new JFrame(), "Message from " + peer + " has been corrupted",
									"ERROR", JOptionPane.ERROR_MESSAGE);
						}

					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) throws Exception {
		c = new Client();
		/////////////////////////////////
		Socket clientSocket = null;
		try {
			ServerSocket serverSocket = new ServerSocket(port);
			int id = 1;
			while (!serverSocket.isClosed()) {
				System.out.println("request to chat");
				clientSocket = serverSocket.accept();
				Peer_Chat th = new Peer_Chat(clientSocket, "", false);
				System.out.println("start thread");
				th.start();

			}

		} catch (IOException e) {
			System.out.println(e.getMessage());

		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand().equals("SEND")) {
			peer = (String) app.onlineUsers.getSelectedItem();
			message = app.inputText.getText();
			if (peer.equals("PICK A USER") && app.tabs.getTabCount() == 0)
				JOptionPane.showMessageDialog(new JFrame(), "Pick a user to chat with!", "ERROR",
						JOptionPane.ERROR_MESSAGE);
			else if (message.length() <= 0) {
				JOptionPane.showMessageDialog(new JFrame(), "Cannot send empty messages!", "ERROR",
						JOptionPane.ERROR_MESSAGE);
			} else if (peer.equals("PICK A USER") && app.tabs.getTabCount() > 0) {
				peer = app.getCurrentActive();
				try {
					Chat.send("isOnline" + delimter + peer, keyGen.getPrivateKey(), serverSocket.getOutputStream());
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			} else {
				if (!connected_peers.containsKey(peer)) {
					try {
						Chat.send("port" + delimter + peer, keyGen.getPrivateKey(), serverSocket.getOutputStream());
					} catch (Exception ex) {
						ex.printStackTrace();
					}
				} else {
					try {
						Chat.send(message, keyGen.getPrivateKey(), connected_peers.get(peer).getOutputStream());
						app.selectbyname(peer);
						app.getCurrentTextArea(peer).append("you: " + message + "\n");
					} catch (Exception ex) {
						ex.printStackTrace();
					}
				}
			}
			app.onlineUsers.setEnabled(false);
			app.onlineUsers.removeAllItems();
			app.onlineUsers.addItem("PICK A USER");
			app.inputText.setText("");
		} else if (e.getActionCommand().equals("login")) {
			try {
				username = login.getuserField().getText();
				System.out.println("Sending public");
				Chat.sendPublic("publicKey" + delimter + username + delimter + keyGen.getPublicKey(),
						serverSocket.getOutputStream());
				Chat.send("login" + delimter + username + delimter + new String(login.getpassField().getPassword()) + delimter + port,
						keyGen.getPrivateKey(), serverSocket.getOutputStream());
				login.getuserField().setText("");
				login.getpassField().setText("");
			} catch (Exception ex) {
				System.out.println(ex.getMessage());
			}

		} else if (e.getActionCommand().equals("ONLINEUSERS")) {
			try {
				Chat.send("getlist" + delimter, keyGen.getPrivateKey(), serverSocket.getOutputStream());
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} else if (e.getActionCommand().equals("SENDTOALL")) {
			message = app.inputText.getText();
			if (message.length() <= 0) {
				JOptionPane.showMessageDialog(new JFrame(), "Cannot send empty messages!", "ERROR",
						JOptionPane.ERROR_MESSAGE);
			} else {
				sendToAll = true;
				app.onlineUsers.setEnabled(false);
				app.onlineUsers.removeAllItems();
				app.onlineUsers.addItem("PICK A USER");
				try {
					Chat.send("portall" + delimter, keyGen.getPrivateKey(), serverSocket.getOutputStream());
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
			app.inputText.setText("");
		}
	}

	public void quit_app() {
		try {
			String s = "bye" + delimter + username;
			Chat.send(s, keyGen.getPrivateKey(), serverSocket.getOutputStream());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void quit_signup_login() {
		try {
			Chat.send("bye" + delimter, keyGen.getPrivateKey(), serverSocket.getOutputStream());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
